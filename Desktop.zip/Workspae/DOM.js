function A_(args){
    if(document.querySelector(args) != undefined){
       let result =  document.querySelector(args)
       
       return result ? {
		x : Number(result[2]),
		y : Number(result[1]),
		color : obj.classList.toString().split(" ")[1].split("_")[1]
	} : null;


    }
   
}

